# Bilingual Defense Question Bank

## A. Core Questions — 核心问题

### 1. ★★★ What is your thesis about in simple terms?

**中文问题：请简单介绍你的论文。**

**English answer**

My thesis develops a two-stage network intrusion detector.

Stage 1 learns one representation for each flow. It uses packet order, elapsed time, and flow statistics.

Stage 2 uses earlier related flows as context.

The main idea is that network traffic is hierarchical. The detector should therefore model both packet-level and flow-level information.

**中文答案**

我的论文提出了一个两阶段网络入侵检测模型。

Stage 1 利用数据包顺序、经过时间和流统计，为每条 flow 学习一个表示。

Stage 2 使用之前的相关 flow 作为上下文。

核心思想是网络流量具有层次结构，因此检测器应该同时建模包级信息和流级信息。

---

### 2. ★★★ What research gap does your thesis address?

**中文问题：你的论文解决了什么研究空白？**

**English answer**

Many NIDS models use only flow statistics.

This removes packet order and detailed timing.

Other models use packet sequences, but still classify every flow independently.

My thesis combines both levels. It models the packet sequence inside a flow and the relations between different flows.

**中文答案**

许多 NIDS 模型只使用流统计，因此会丢失数据包顺序和详细时间信息。

另一些模型使用数据包序列，但仍然独立分类每条 flow。

我的论文结合了两个层次：既建模 flow 内部的数据包序列，也建模不同 flow 之间的关系。

---

### 3. ★★★ What is the main novelty?

**中文问题：论文的主要创新是什么？**

**English answer**

The novelty is not the Transformer alone.

The main contribution is the hierarchical design.

Stage 1 combines packet order, cumulative time, and bounded flow-statistics conditioning.

Stage 2 uses the target flow as a query over earlier related flows.

The two levels are evaluated separately and together.

**中文答案**

创新点并不是单独使用 Transformer。

主要贡献是层次化设计。

Stage 1 结合数据包顺序、累计时间和有界的流统计调制。

Stage 2 使用目标 flow 查询之前的相关 flow。

论文分别评估了两个层次以及完整系统。

---

### 4. ★★★ Why do you need two stages?

**中文问题：为什么需要两个阶段？**

**English answer**

The two stages answer different questions.

Stage 1 asks how one flow develops internally.

Stage 2 asks whether earlier related flows change the meaning of the current flow.

A single flat model may mix these two problems.

The separation also makes the experiments easier to interpret.

**中文答案**

两个阶段回答不同的问题。

Stage 1 研究一条 flow 内部是如何发展的。

Stage 2 研究之前的相关 flow 是否会改变当前 flow 的含义。

单一的扁平模型可能会混合这两个问题。分阶段也使实验更容易解释。

---

### 5. Why do you use flow-level prediction?

**中文问题：为什么最终做 flow-level 预测？**

**English answer**

A flow represents one network conversation.

It is a practical unit for network monitoring and alert generation.

Packet-level prediction can produce many repeated alerts for the same connection.

Flow-level prediction gives one decision for each connection while still using packet-level evidence.

**中文答案**

一条 flow 表示一次网络通信。

它是网络监控和告警生成中较实用的单位。

包级预测可能会对同一个连接产生大量重复告警。

流级预测仍然可以使用包级证据，但每个连接只产生一个判断。

---

### 6. Why do you not use payload content?

**中文问题：为什么不使用 payload 内容？**

**English answer**

Payload content may be encrypted or sensitive.

It can also create privacy and storage problems.

My model uses packet metadata, timing, direction, and flow statistics.

This makes the approach more suitable for encrypted traffic, but it may miss attacks that are visible only in application content.

**中文答案**

Payload 内容可能被加密，也可能包含敏感信息。

使用 payload 还会带来隐私和存储问题。

我的模型使用数据包元数据、时间、方向和流统计。

这种设计更适用于加密流量，但可能漏掉只能通过应用内容发现的攻击。

---

### 7. What are your two research questions?

**中文问题：你的两个研究问题是什么？**

**English answer**

RQ1 asks whether time-aware packet-sequence modelling produces a better flow representation than flow statistics alone.

RQ2 asks whether earlier related flows improve detection compared with independent flow classification.

The results support both questions within the tested setting.

**中文答案**

RQ1 研究时间感知的数据包序列是否比单独使用流统计产生更好的 flow 表示。

RQ2 研究使用之前的相关 flow 是否优于独立 flow 分类。

在当前实验范围内，结果支持这两个研究问题。

---

### 8. What is your strongest contribution?

**中文问题：你认为最重要的贡献是什么？**

**English answer**

I think the strongest contribution is the complete hierarchy.

Stage 1 preserves information inside a flow.

Stage 2 adds information between flows.

The experiments show that these two information levels are complementary.

However, the result is limited by weak labels and the tested datasets.

**中文答案**

我认为最重要的贡献是完整的层次结构。

Stage 1 保留 flow 内部的信息。

Stage 2 添加 flow 之间的信息。

实验表明这两个信息层次具有互补性，但结果受到弱标签和测试数据范围的限制。

---

## B. Data and Labels — 数据与标签

### 9. ★★★ Where does your dataset come from?

**中文问题：你的数据集来自哪里？**

**English answer**

The main dataset comes from an enterprise PCAP supplied by the company.

Its size is about 8.62 gigabytes.

After extraction, it contains 11.75 million packet records and 421,898 flow records.

It represents real enterprise traffic observed at one collection point.

**中文答案**

主要数据来自公司提供的企业 PCAP。

数据大小约为 8.62 GB。

提取后包含 1175 万条 packet 记录和 421,898 条 flow 记录。

它代表一个采集点观察到的真实企业网络流量。

---

### 10. ★★★ What does class 1 mean?

**中文问题：class 1 具体表示什么？**

**English answer**

Class 1 means that at least one packet in the flow triggered a Suricata alert.

It does not mean that the attack was independently verified.

Therefore, I call these weak labels.

My conclusions concern Suricata-alert-associated behaviour, not perfect attack ground truth.

**中文答案**

Class 1 表示一条 flow 中至少有一个 packet 触发了 Suricata 告警。

它不表示攻击经过了独立人工验证。

因此，这些是弱标签。

论文结论针对的是与 Suricata 告警相关的行为，而不是完美的真实攻击标签。

---

### 11. ★★★ Is your model only learning to copy Suricata?

**中文问题：你的模型是否只是在模仿 Suricata？**

**English answer**

This is an important limitation.

The labels come from Suricata, but the model does not receive rule IDs, alert text, alert counts, or packet labels as inputs.

It learns patterns associated with the alerts.

However, without independent ground truth, I cannot prove that it learns all real attacks or zero-day attacks.

**中文答案**

这是一个重要限制。

标签来自 Suricata，但模型输入中不包含规则 ID、告警文本、告警数量或 packet 标签。

模型学习的是与告警相关的行为模式。

但是，没有独立真实标签，我不能证明模型学到了所有真实攻击或零日攻击。

---

### 12. Could label 0 still contain attacks?

**中文问题：label 0 中是否仍然可能包含攻击？**

**English answer**

Yes.

Label 0 only means that Suricata did not generate an alert.

It does not guarantee that the flow is benign.

Suricata may miss an attack.

This label noise may affect both training and evaluation.

**中文答案**

是的。

Label 0 只表示 Suricata 没有生成告警。

它并不能保证这条 flow 一定是正常流量。

Suricata 可能漏报攻击，这种标签噪声可能影响训练和评估。

---

### 13. How did you align packets and flows?

**中文问题：你如何对齐 packet 和 flow？**

**English answer**

I used a custom Suricata output module.

It writes packet records and flow records during the same PCAP replay.

Both outputs use the same bidirectional flow ID.

This avoids reconstructing packet-to-flow membership with a separate tool.

**中文答案**

我使用了一个自定义 Suricata 输出模块。

它在同一次 PCAP 回放中同时输出 packet 记录和 flow 记录。

两个输出使用同一个双向 flow ID。

这样不需要使用其他工具重新构建 packet 与 flow 的对应关系。

---

### 14. How did you protect sensitive IP addresses?

**中文问题：你如何保护敏感 IP 地址？**

**English answer**

IP addresses are not used as Stage 1 prediction features.

They are kept only in local metadata for Stage 2 relation matching.

They are not shown in the thesis.

For data release, they should be replaced with stable pseudonyms. The pseudonyms must preserve equality relations.

**中文答案**

IP 地址不作为 Stage 1 的预测特征。

它们只保存在本地元数据中，用于构建 Stage 2 关系。

论文中没有展示这些地址。

如果发布数据，应使用稳定的假名替换 IP，同时保留地址相等关系。

---

## C. Leakage and Experimental Design — 泄漏与实验设计

### 15. ★★★ How did you prevent data leakage?

**中文问题：你如何防止数据泄漏？**

**English answer**

I split the data at flow level and in chronological order.

All packets from one flow stay in the same partition.

Clipping limits, scaling values, and category vocabularies are fitted only on training data.

Labels and Suricata alert fields are excluded from model inputs.

**中文答案**

我在 flow 层面按照时间顺序划分数据。

同一条 flow 的所有 packet 都进入同一个分区。

截断范围、缩放参数和类别词表只通过训练数据拟合。

标签和 Suricata 告警字段不进入模型输入。

---

### 16. Why did you use a chronological split?

**中文问题：为什么使用时间顺序划分？**

**English answer**

A chronological split is closer to real deployment.

The model is trained on earlier traffic and tested on later traffic.

A random split could place very similar or nearby traffic in both training and test sets.

That could produce an optimistic result.

**中文答案**

时间顺序划分更接近真实部署。

模型使用较早的流量训练，并在较晚的流量上测试。

随机划分可能把非常相似或时间相邻的流量同时放入训练集和测试集，从而产生过于乐观的结果。

---

### 17. What is the exact split?

**中文问题：具体的数据划分是什么？**

**English answer**

Flows are sorted by start time.

The earliest 70 percent are used for training.

The next 10 percent are used for validation.

The final 20 percent are used for testing.

The complete test partition contains 84,380 flows.

**中文答案**

所有 flow 按开始时间排序。

最早的 70% 用于训练，接下来的 10% 用于验证，最后 20% 用于测试。

完整测试集包含 84,380 条 flow。

---

### 18. Why are IP addresses and ports excluded as predictors?

**中文问题：为什么不把 IP 地址和端口作为预测特征？**

**English answer**

These fields can identify specific machines or services.

The model might memorise which hosts produced alerts during training.

That would reduce generalisation.

I use host identity only to define Stage 2 relations, not as a semantic prediction feature.

**中文答案**

IP 地址和端口可能直接标识特定机器或服务。

模型可能记住训练期间哪些主机经常产生告警，这会降低泛化能力。

我只使用主机身份构建 Stage 2 关系，而不把它作为语义预测特征。

---

## D. Metrics and Imbalance — 指标与类别不平衡

### 19. ★★★ Why is accuracy not your main metric?

**中文问题：为什么 accuracy 不是主要指标？**

**English answer**

Only 3.945 percent of the flows are positive.

An always-negative model would achieve about 96.1 percent accuracy.

However, it would detect no positive flow.

Therefore, I focus on macro-F1, class-1 F1, AP, false-positive rate, FP, and FN.

**中文答案**

只有 3.945% 的 flow 是阳性。

如果模型把所有 flow 都预测为阴性，accuracy 仍然约为 96.1%，但它检测不到任何阳性 flow。

因此，我重点使用 macro-F1、class-1 F1、AP、FPR、FP 和 FN。

---

### 20. ★★★ Is AP the same as PR-AUC?

**中文问题：AP 和 PR-AUC 是一样的吗？**

**English answer**

Not exactly.

My code uses scikit-learn’s Average Precision score.

In the thesis, I label this value as PR-AUC for consistency with the experiment logs.

It is not calculated with trapezoidal integration.

Every reported PR-AUC value in my thesis should be understood as AP.

**中文答案**

不完全一样。

我的代码使用 scikit-learn 的 Average Precision。

为了与实验日志保持一致，论文把它标记为 PR-AUC。

它不是通过梯形积分计算的。

论文中所有 PR-AUC 数值都应理解为 AP。

---

### 21. Why use macro-F1?

**中文问题：为什么使用 macro-F1？**

**English answer**

Macro-F1 calculates F1 for each class and gives both classes equal weight.

The positive class is rare, so weighted F1 would be dominated by the negative class.

Macro-F1 therefore gives a more balanced view of the two classes.

**中文答案**

Macro-F1 分别计算两个类别的 F1，然后给予两个类别相同权重。

由于阳性类很少，weighted F1 会被阴性类主导。

因此，macro-F1 能更平衡地反映两个类别的表现。

---

### 22. Why report both PR-AUC and class-1 F1?

**中文问题：为什么同时报告 PR-AUC 和 class-1 F1？**

**English answer**

Class-1 F1 measures performance at one selected threshold.

AP measures ranking performance across many thresholds.

A model may rank samples well but perform poorly at one threshold.

Reporting both helps separate ranking quality from threshold selection.

**中文答案**

Class-1 F1 衡量模型在一个选定阈值下的表现。

AP 衡量多个阈值下的排序能力。

一个模型可能排序能力很好，但在某个固定阈值下表现较差。

同时报告两者可以区分排序质量和阈值选择问题。

---

### 23. How did you select the decision threshold?

**中文问题：你如何选择决策阈值？**

**English answer**

The model checkpoint is selected using validation PR-AUC, meaning AP.

After that, the threshold is selected using validation class-1 F1.

The selected threshold is then fixed.

The test set is not used for checkpoint or threshold selection.

**中文答案**

模型 checkpoint 根据验证集 PR-AUC，也就是 AP，进行选择。

然后根据验证集 class-1 F1 选择决策阈值。

阈值选定后保持不变。

测试集不参与 checkpoint 或阈值选择。

---

### 24. Why use focal loss and weighted sampling together?

**中文问题：为什么同时使用 focal loss 和加权采样？**

**English answer**

They address different parts of the imbalance problem.

Weighted sampling increases the number of positive examples in training batches.

Focal loss reduces the influence of easy examples.

However, the combination may also affect calibration. This should be studied further.

**中文答案**

它们处理类别不平衡的不同方面。

加权采样提高训练 batch 中阳性样本的比例。

Focal loss 降低容易分类样本的影响。

但这种组合也可能影响概率校准，需要进一步研究。

---

## E. Stage 1 Questions — Stage 1 问题

### 25. ★★★ Why did you choose a Transformer for Stage 1?

**中文问题：为什么 Stage 1 使用 Transformer？**

**English answer**

A Transformer allows distant packets to interact directly.

It can model long-range dependencies without recurrent transitions.

Training can also be parallelised.

I still compare it with LSTM, GRU, BiLSTM, and CNN baselines.

**中文答案**

Transformer 允许相距较远的数据包直接交互。

它不需要递归状态，也可以建模长距离依赖。

训练还可以并行化。

论文同时与 LSTM、GRU、BiLSTM 和 CNN 基线进行了比较。

---

### 26. ★★★ Why combine packet position and cumulative time?

**中文问题：为什么同时使用 packet position 和 cumulative time？**

**English answer**

They describe different information.

Position tells the model where a packet appears.

Cumulative time tells the model how much real time has passed.

The same packet order may represent a fast burst or a slow interaction.

The results show that using both works better than using either one alone.

**中文答案**

它们描述不同的信息。

Position 表示数据包在序列中的位置。

Cumulative time 表示实际经过了多长时间。

相同的数据包顺序可能表示快速突发，也可能表示缓慢交互。

结果表明同时使用两者优于单独使用其中一个。

---

### 27. Why use cumulative time instead of only inter-arrival time?

**中文问题：为什么使用累计时间，而不是只使用相邻包间隔？**

**English answer**

An individual interval describes only one local gap.

Cumulative time gives every packet a position on the complete flow timeline.

It allows the encoding to represent both order and total elapsed time.

The intervals are log-transformed to reduce the effect of extreme gaps.

**中文答案**

单个 inter-arrival time 只描述一个局部时间间隔。

累计时间为每个 packet 提供完整 flow 时间线上的位置。

这样编码能够同时表示顺序和总经过时间。

时间间隔还进行对数变换，以降低极端值的影响。

---

### 28. What is Scheme C?

**中文问题：Scheme C 是什么？**

**English answer**

Scheme C uses a separate flow-statistics branch.

The branch encodes the flow statistics once.

It then generates a small feature-wise correction for the packet tokens.

This is different from Scheme A, which repeats the same flow-statistics vector at every packet position.

**中文答案**

Scheme C 使用一个独立的 flow-statistics 分支。

该分支只编码一次流统计，然后为 packet token 生成较小的特征级修正。

这与 Scheme A 不同。Scheme A 会在每个 packet 位置重复同一个流统计向量。

---

### 29. Why bound the flow-statistics correction?

**中文问题：为什么要限制 flow-statistics correction？**

**English answer**

Flow statistics are useful, but they may be noisy or capture-specific.

Without a bound, they could dominate the packet representation.

The model starts close to the packet-only path.

It then learns a limited correction from the flow statistics.

**中文答案**

流统计很有用，但也可能包含噪声或数据采集环境特有的信息。

如果不限制，流统计可能主导 packet 表示。

模型从接近 packet-only 的路径开始，然后逐渐学习有限的流统计修正。

---

### 30. Why use attention, mean, and max pooling together?

**中文问题：为什么同时使用 attention、mean 和 max pooling？**

**English answer**

Each pooling method captures different information.

Attention pooling can focus on important packets.

Mean pooling represents the overall flow behaviour.

Max pooling keeps strong local signals.

Their combination gives a fixed-size representation for every flow.

**中文答案**

三种 pooling 捕捉不同的信息。

Attention pooling 可以关注重要数据包。

Mean pooling 表示 flow 的整体行为。

Max pooling 保留强烈的局部信号。

三者结合后，为每条 flow 生成固定长度表示。

---

### 31. Why is there no causal mask in Stage 1?

**中文问题：为什么 Stage 1 不使用 causal mask？**

**English answer**

Stage 1 classifies a completed or truncated flow.

Every retained packet can therefore attend to every other retained packet.

The model is not designed for packet-by-packet early detection.

A real early-detection system would require a causal mask or a fixed observation deadline.

**中文答案**

Stage 1 对已经完成或截断的 flow 进行分类。

因此，每个保留的 packet 可以关注其他所有保留的 packet。

该模型不是逐 packet 的早期检测系统。

真正的早期检测需要 causal mask 或固定的观察截止时间。

---

### 32. ★★★ Why did you choose 128 packets?

**中文问题：为什么选择 128 个 packet？**

**English answer**

I tested sequence limits from 8 to 256 packets.

Performance was not monotonic.

The 128-packet setting gave the best observed macro-F1 and overall error balance.

At 256 packets, false positives increased by 46, and macro-F1 and AP decreased.

It is an empirical choice, not a universal optimum.

**中文答案**

我测试了从 8 到 256 的序列长度。

性能并不是单调提高的。

128 个 packet 获得了最佳观察到的 macro-F1 和综合错误平衡。

增加到 256 后，FP 增加 46，macro-F1 和 AP 都下降。

这是实验选择，不是普遍最优值。

---

### 33. Why use head packet selection?

**中文问题：为什么使用 head selection？**

**English answer**

Head selection keeps the first packets of the flow.

It is deterministic and preserves one continuous early sequence.

Head and head-tail perform very similarly.

Random selection gives fewer false positives, but it misses more positive flows.

Therefore, I selected head as the practical default.

**中文答案**

Head selection 保留 flow 开始部分的数据包。

它是确定性的，并保留一个连续的早期序列。

Head 和 head-tail 的表现非常接近。

Random selection 的误报更少，但漏掉更多阳性 flow。

因此，我把 head 作为实际默认选择。

---

### 34. Why may 256 packets perform worse?

**中文问题：为什么 256 个 packet 反而表现更差？**

**English answer**

The experiment does not prove the exact reason.

Later packets may add noise or dilute useful early patterns.

Longer sequences may also change optimisation and flow-length coverage.

A length-stratified analysis would be needed to identify the real cause.

**中文答案**

当前实验不能证明确切原因。

后面的 packet 可能增加噪声，或者稀释早期有用模式。

更长序列也可能改变优化过程和不同 flow 长度的覆盖情况。

需要按 flow 长度分层分析才能确定真正原因。

---

### 35. What is the main Stage 1 result?

**中文问题：Stage 1 的主要结果是什么？**

**English answer**

The complete Scheme C representation reaches a macro-F1 of 0.8954 and an AP of 0.8763.

The position-plus-time packet encoder clearly outperforms the flow-statistics MLP.

The results support using packet order, elapsed time, and carefully integrated flow statistics together.

**中文答案**

完整的 Scheme C 表示获得 0.8954 的 macro-F1 和 0.8763 的 AP。

Position-plus-time packet encoder 明显优于 flow-statistics MLP。

结果支持同时使用 packet 顺序、经过时间和经过谨慎融合的流统计。

---

## F. Stage 1–Stage 2 Connection — 两阶段结果衔接

### 36. ★★★ Do Stage 1 and Stage 2 use the same test set?

**中文问题：Stage 1 和 Stage 2 是否使用同一个测试集？**

**English answer**

There are two test manifests.

Stage 1 ablations use 35,410 test flows.

The complete Stage 1 reference and all Stage 2 experiments use the full 84,380-flow test set.

Only results from the same manifest should be compared directly.

**中文答案**

论文使用了两个测试 manifest。

Stage 1 消融实验使用 35,410 条测试 flow。

完整 Stage 1 参考结果和所有 Stage 2 实验使用 84,380 条 flow 的完整测试集。

只有来自同一个 manifest 的结果才能直接比较。

---

### 37. ★★★ Why are the Stage 1 numbers identical on two different manifests?

**中文问题：为什么两个不同 manifest 上的 Stage 1 数值完全相同？**

**English answer**

The macro-F1 and AP values are the same after rounding, but they are different evaluations.

The smaller manifest has 267 FP and 293 FN.

The full manifest has about 667 FP and 732 FN.

For the Stage 1 to Stage 2 comparison, I use only the full manifest results.

**中文答案**

两个 manifest 的 macro-F1 和 AP 在四舍五入后相同，但它们是不同的评估。

较小 manifest 有 267 个 FP 和 293 个 FN。

完整 manifest 约有 667 个 FP 和 732 个 FN。

Stage 1 与 Stage 2 的比较只使用完整 manifest。

---

### 38. Did Stage 2 use the selected Scheme C embeddings?

**中文问题：Stage 2 是否使用了选定的 Scheme C embedding？**

**English answer**

Yes.

I restore the validation-selected Stage 1 Scheme C checkpoint.

I then export one embedding for every flow.

These embeddings are fixed during Stage 2 training.

All Stage 2 models use the same embedding files and context indices.

**中文答案**

是的。

我恢复通过验证集选择的 Stage 1 Scheme C checkpoint。

然后为每条 flow 导出一个 embedding。

这些 embedding 在 Stage 2 训练期间保持固定。

所有 Stage 2 模型使用相同的 embedding 文件和上下文索引。

---

## G. Stage 2 Questions — Stage 2 问题

### 39. ★★★ How is the Stage 2 context constructed?

**中文问题：Stage 2 上下文是如何构建的？**

**English answer**

Flows are ordered by start time and flow ID.

For each target, I retrieve eligible earlier flows.

I keep at most 127 historical flows and append the target as the final token.

Historical labels are never used.

Padding is excluded by a mask.

**中文答案**

Flow 按开始时间和 flow ID 排序。

对于每个目标 flow，我检索符合条件的较早 flow。

最多保留 127 条历史 flow，并把目标 flow 放在最后一个 token。

历史标签不会被使用，padding 通过 mask 排除。

---

### 40. ★★★ Why does source-host context work best?

**中文问题：为什么 source-host context 表现最好？**

**English answer**

Source-host context may capture repeated behaviour from one initiator.

Examples include scanning, retries, or coordinated connections.

Global time context may mix unrelated flows.

However, this explanation is only a hypothesis because the binary labels do not identify attack families.

**中文答案**

Source-host context 可能捕捉同一个发起者的重复行为。

例如扫描、重试或协调连接。

全局时间上下文可能混入无关 flow。

但这只是一种假设，因为二分类标签不能识别具体攻击家族。

---

### 41. Why does endpoint context have higher recall but more false positives?

**中文问题：为什么 endpoint context 的 recall 更高，但 FP 也更多？**

**English answer**

Endpoint context includes any flow sharing a source or destination endpoint.

This retrieves a broader history.

The broader history may contain more useful attack evidence, but also more unrelated normal traffic.

Therefore, recall increases, but false alarms also increase.

**中文答案**

Endpoint context 包含共享任意源端点或目标端点的 flow。

因此，它检索的历史范围更广。

更广的历史可能包含更多攻击证据，但也包含更多无关正常流量。

所以 recall 提高，同时误报也增加。

---

### 42. Why use a target-query model instead of full self-attention?

**中文问题：为什么使用 target-query，而不是完整 self-attention？**

**English answer**

The final decision concerns the current flow.

Therefore, I use the current flow as the only query.

The historical flows act as keys and values.

This keeps a direct path for the current representation.

It also avoids a full context-by-context attention matrix.

**中文答案**

最终判断的对象是当前 flow。

因此，我只使用当前 flow 作为 query。

历史 flow 作为 keys 和 values。

这样可以保留当前表示的直接路径，也避免构建完整的上下文两两注意力矩阵。

---

### 43. What does the gate do?

**中文问题：gate 的作用是什么？**

**English answer**

The gate controls how much the historical summary changes each feature of the current flow.

If the context is useful, the model can apply a stronger update.

If the context is not useful, the current-flow representation can pass through with little change.

**中文答案**

Gate 控制历史摘要在多大程度上修改当前 flow 的每一个特征。

如果上下文有用，模型可以应用较强更新。

如果上下文没有用，当前 flow 表示可以基本保持不变。

---

### 44. What happens when a flow has no history?

**中文问题：如果一条 flow 没有历史上下文，会发生什么？**

**English answer**

The historical summary is set to zero.

The gate and context update are also set to zero.

The current-flow representation then passes through unchanged.

This prevents artificial padding tokens from creating fake context.

**中文答案**

历史摘要会被设置为零。

Gate 和 context update 也会被设置为零。

当前 flow 的表示保持不变。

这样可以防止 padding token 产生虚假的上下文。

---

### 45. Why choose a context window of 128?

**中文问题：为什么选择 128 的上下文窗口？**

**English answer**

I tested window sizes from 16 to 256.

The result was not monotonic.

A window of 128 gave the best observed macro-F1, AP, and false-positive rate.

At 256, both false positives and false negatives increased.

Again, this is not a universal optimum.

**中文答案**

我测试了从 16 到 256 的上下文窗口。

结果不是单调变化的。

128 在 macro-F1、AP 和 FPR 上获得最佳综合结果。

增加到 256 后，FP 和 FN 都增加。

这同样不是普遍最优值。

---

### 46. ★★★ What is the main Stage 2 improvement?

**中文问题：Stage 2 带来了多大提升？**

**English answer**

On the same full test manifest, macro-F1 increases from 0.8954 to 0.9275.

AP increases from 0.8763 to 0.9345.

Stage 2 removes 228 false positives and 205 false negatives.

Therefore, both types of errors decrease.

**中文答案**

在同一个完整测试 manifest 上，macro-F1 从 0.8954 提高到 0.9275。

AP 从 0.8763 提高到 0.9345。

Stage 2 减少了 228 个 FP 和 205 个 FN。

因此，两种错误都下降了。

---

### 47. ★★★ Can you prove that the improvement comes only from context?

**中文问题：你能证明提升完全来自上下文吗？**

**English answer**

No, not completely.

Stage 2 adds context, a new classification head, gating, and additional model capacity.

The no-context MLP is not parameter-matched.

Therefore, Table 6.2 proves that the complete Stage 2 system is better.

It does not isolate the pure causal effect of context.

**中文答案**

不能完全证明。

Stage 2 同时增加了上下文、新分类头、gating 和额外模型容量。

No-context MLP 也没有进行参数量匹配。

因此，表 6.2 证明的是完整 Stage 2 系统更好，而不能完全隔离上下文本身的因果贡献。

---

### 48. Why freeze Stage 1 instead of training end-to-end?

**中文问题：为什么冻结 Stage 1，而不是端到端训练？**

**English answer**

Freezing Stage 1 makes the Stage 2 comparisons easier to interpret.

All Stage 2 models receive exactly the same flow representations.

It also reduces training cost.

However, it may limit performance because Stage 1 cannot adapt to the needs of Stage 2.

**中文答案**

冻结 Stage 1 使 Stage 2 的比较更容易解释。

所有 Stage 2 模型使用完全相同的 flow 表示。

这也能降低训练成本。

但它可能限制性能，因为 Stage 1 无法针对 Stage 2 的需求进行调整。

---

## H. Validity and Limitations — 效度与局限性

### 49. ★★★ Is Stage 2 strictly causal and suitable for streaming?

**中文问题：Stage 2 是否严格因果并适合流式部署？**

**English answer**

Not yet.

Context is ordered by flow start time.

An earlier flow may still be active when the target starts.

Its complete embedding may not be available at that moment.

A strict streaming version should use flow completion time or embedding availability time.

**中文答案**

目前还不是。

上下文按照 flow 开始时间排序。

较早开始的 flow 在目标 flow 开始时可能仍未结束。

此时它的完整 embedding 可能还不可用。

严格流式版本应使用 flow 完成时间或 embedding 实际可用时间。

---

### 50. ★★★ Why did you use only one random seed?

**中文问题：为什么只使用一个随机种子？**

**English answer**

The main reason was limited compute and project time.

A single seed is not enough to estimate run-to-run variation.

Therefore, small differences should not be treated as statistically significant.

Future work should repeat the main experiments with several seeds.

**中文答案**

主要原因是计算资源和项目时间有限。

单个随机种子无法估计不同运行之间的波动。

因此，不应该把较小差异解释为具有统计显著性。

未来应使用多个随机种子重复主要实验。

---

### 51. Are your results statistically significant?

**中文问题：你的结果具有统计显著性吗？**

**English answer**

I did not perform statistical significance testing across repeated runs.

The experiments use one fixed seed.

Large differences and consistent FP and FN reductions are meaningful descriptive evidence.

However, I cannot claim statistical significance.

**中文答案**

我没有基于多次重复运行进行统计显著性检验。

实验只使用了一个固定随机种子。

较大差异以及 FP、FN 的同时下降具有描述性意义，但我不能声称它们具有统计显著性。

---

### 52. Can the model generalise to other networks?

**中文问题：模型可以泛化到其他网络吗？**

**English answer**

The external tests provide preliminary evidence.

The pooled CICIDS2017 macro-F1 is 0.8966.

The different company server reaches 0.9026.

However, performance varies across windows.

The results do not prove universal generalisation.

**中文答案**

外部测试提供了初步证据。

CICIDS2017 pooled macro-F1 为 0.8966。

不同公司服务器上的 macro-F1 为 0.9026。

但不同时间窗口的性能存在变化，因此结果不能证明普遍泛化。

---

### 53. Why did you select only five CICIDS2017 windows?

**中文问题：为什么只选择五个 CICIDS2017 时间窗口？**

**English answer**

I kept windows where the positive class remained the minority.

This matched the qualitative imbalance direction of the source task.

The selection was based on class composition, not model scores.

However, it limits the claim to those windows, not the full Wednesday capture.

**中文答案**

我保留了阳性类仍然为少数类的时间窗口。

这与源数据任务的类别不平衡方向一致。

窗口选择基于类别组成，而不是模型表现。

但是，这也把结论限制在这些窗口内，而不是完整的 Wednesday 数据。

---

### 54. Why does one external window have high AP but low recall?

**中文问题：为什么某个外部窗口 AP 很高，但 recall 很低？**

**English answer**

This may indicate a threshold or calibration shift.

The model still ranks positive flows reasonably well.

However, the source-domain threshold may not fit that external window.

Confirming this would require an independent external validation set.

**中文答案**

这可能表示阈值或概率校准发生了偏移。

模型仍然可以较好地对阳性 flow 进行排序。

但是，源域选择的阈值可能不适合该外部窗口。

要确认这一点，需要独立的外部验证集。

---

### 55. What reproducibility information is missing?

**中文问题：还缺少哪些可复现性信息？**

**English answer**

The exact CPU, software versions, Suricata version, ruleset snapshot, custom-module revision, and PCAP checksum were not fully retained.

This limits exact reproduction.

Future experiments should store the complete environment and label-generation configuration.

**中文答案**

没有完整保存精确 CPU、软件版本、Suricata 版本、规则集快照、自定义模块 revision 和 PCAP checksum。

这限制了实验的精确复现。

未来实验应保存完整运行环境和标签生成配置。

---

### 56. What is the biggest limitation?

**中文问题：最大的局限是什么？**

**English answer**

The biggest limitation is the weak label quality.

The model is evaluated against Suricata-derived labels, not independently verified attacks.

The start-time context boundary and the single-seed design are also important limitations.

**中文答案**

最大的局限是弱标签质量。

模型通过 Suricata 生成的标签进行评估，而不是通过独立验证的攻击标签。

此外，start-time 上下文边界和单随机种子设计也是重要限制。

---

## I. Efficiency and Deployment — 效率与部署

### 57. What is the Stage 2 inference speed?

**中文问题：Stage 2 的推理速度是多少？**

**English answer**

The proposed Stage 2 model takes about 0.1965 milliseconds per flow.

This is about 5,089 flows per second on the measured NVIDIA L4 path.

However, this excludes PCAP processing, Suricata extraction, Stage 1, and context construction.

It is model-level latency, not end-to-end latency.

**中文答案**

所提出的 Stage 2 模型每条 flow 大约需要 0.1965 毫秒。

在 NVIDIA L4 的测量路径上约为每秒 5,089 条 flow。

但这个数字不包括 PCAP 处理、Suricata 提取、Stage 1 和上下文构建。

它是模型级延迟，不是端到端延迟。

---

### 58. How would you deploy this system with Suricata?

**中文问题：如何把该系统与 Suricata 一起部署？**

**English answer**

Suricata can extract packet and flow metadata.

Stage 1 can generate an embedding when enough packets are observed or when the flow ends.

A bounded context buffer can store recent embeddings for each relation.

Stage 2 can then produce the final score.

A production system also needs monitoring, logging, and fallback behaviour.

**中文答案**

Suricata 可以提取 packet 和 flow 元数据。

当观察到足够数据包或 flow 结束时，Stage 1 可以生成 embedding。

系统可以为每种关系维护一个有界上下文缓冲区。

Stage 2 随后生成最终分数。

生产系统还需要监控、日志和故障回退机制。

---

### 59. How would you manage false positives in practice?

**中文问题：在实际部署中如何管理误报？**

**English answer**

I would not use one fixed threshold for every environment.

The threshold should be selected using local validation data and operational cost.

Alerts can also be ranked by score.

High-score flows can receive immediate attention, while lower-score flows can be grouped or reviewed later.

**中文答案**

我不会对所有环境使用同一个固定阈值。

应根据本地验证数据和实际错误成本选择阈值。

还可以按照模型分数对告警排序。

高分 flow 可以立即处理，低分 flow 可以合并或稍后审查。

---

### 60. How would you handle concept drift?

**中文问题：如何处理 concept drift？**

**English answer**

I would monitor score distributions, alert rates, and confirmed error rates over time.

A recent labelled validation window could be used to recalibrate the threshold.

The model may also need periodic retraining.

The update process must avoid using future information.

**中文答案**

我会持续监控模型分数分布、告警率和经过确认的错误率。

可以使用最近的有标签验证窗口重新校准阈值。

模型也可能需要定期重新训练。

更新过程必须避免使用未来信息。

---

### 61. What happens behind NAT or shared servers?

**中文问题：NAT 或共享服务器环境会产生什么问题？**

**English answer**

Many devices may share one visible IP address.

Source-host or endpoint context may then mix unrelated users or services.

This can reduce context quality and increase false positives.

Future work should consider service, subnet, protocol, or learned relation information.

**中文答案**

在 NAT 环境中，多个设备可能共享一个可见 IP 地址。

Source-host 或 endpoint context 可能混合不相关的用户或服务。

这会降低上下文质量，并增加误报。

未来可以考虑 service、subnet、protocol 或学习得到的关系。

---

### 62. Can an attacker evade this model?

**中文问题：攻击者能否规避这个模型？**

**English answer**

Yes, this is possible.

An attacker may change timing, split activity across hosts, slow down scanning, or imitate normal traffic.

My thesis does not evaluate adversarial robustness.

Future work should test timing perturbations, missing packets, spoofed identities, and adaptive attacks.

**中文答案**

有这种可能。

攻击者可能改变时间模式、把行为分散到多个主机、降低扫描速度或模仿正常流量。

论文没有评估对抗鲁棒性。

未来应测试时间扰动、packet 丢失、身份伪造和自适应攻击。

---

## J. Future Work — 未来工作

### 63. Why is self-supervised learning useful here?

**中文问题：为什么自监督学习可能有用？**

**English answer**

Large amounts of network traffic do not have reliable labels.

Self-supervised learning could learn general packet and timing patterns from unlabelled data.

Possible tasks include masked feature prediction, next-packet prediction, and order verification.

The representation could then be fine-tuned for intrusion detection.

**中文答案**

大量网络流量没有可靠标签。

自监督学习可以从无标签数据中学习通用的 packet 和时间模式。

可能的任务包括 masked feature prediction、next-packet prediction 和顺序验证。

然后可以针对入侵检测对表示进行微调。

---

### 64. How would you improve Stage 2?

**中文问题：你会如何改进 Stage 2？**

**English answer**

I would use several relation types together.

The model could learn whether source, destination, endpoint, service, or subnet context is more useful for each target.

I would also use completion-time eligibility and real elapsed-time gaps.

This would make the model more adaptive and more suitable for streaming.

**中文答案**

我会同时使用多种关系。

模型可以针对每个目标学习 source、destination、endpoint、service 或 subnet 上下文中哪一种更有用。

我还会使用基于完成时间的上下文资格和真实经过时间。

这样模型会更加自适应，也更适合流式部署。

---

### 65. What would you do if you had more time?

**中文问题：如果有更多时间，你会做什么？**

**English answer**

First, I would create a manually verified test subset.

Second, I would repeat the main experiments with several random seeds.

Third, I would implement strict streaming context.

Finally, I would test more organisations, time periods, and attack families.

**中文答案**

首先，我会建立一个经过人工验证的测试子集。

其次，我会使用多个随机种子重复主要实验。

第三，我会实现严格流式上下文。

最后，我会测试更多组织、时间段和攻击家族。

---

## K. Committee-Specific High-Probability Questions — 委员个人高概率问题

### 66. [Özlem] Can this model run on edge devices?

**中文问题：该模型能否在边缘设备上运行？**

**English answer**

Stage 2 is relatively small and efficient.

Stage 1 is more expensive because it processes packet sequences.

For an edge deployment, I would test smaller dimensions, fewer layers, quantisation, and shorter sequences.

The complete edge cost was not measured in this thesis.

**中文答案**

Stage 2 相对较小并且效率较高。

Stage 1 的开销更大，因为它处理 packet 序列。

边缘部署可以测试更小维度、更少层数、量化和更短序列。

论文没有测量完整的边缘设备成本。

---

### 67. [Özlem] How robust is the system to missing packets or sensor noise?

**中文问题：系统对 packet 丢失或采集噪声有多鲁棒？**

**English answer**

This was not directly tested.

Packet loss changes sequence length, timing, and flow statistics.

The mask handles padding, but it does not solve real packet loss.

Future tests should introduce controlled packet loss, timestamp noise, and missing features.

**中文答案**

论文没有直接测试这一点。

Packet 丢失会改变序列长度、时间和流统计。

Mask 可以处理 padding，但不能解决真实 packet 丢失。

未来应加入受控 packet loss、时间戳噪声和缺失特征测试。

---

### 68. [Duc] Why not train the full hierarchy end-to-end?

**中文问题：为什么不进行完整端到端训练？**

**English answer**

The main goal was to study the two levels separately.

Freezing Stage 1 gives all Stage 2 models the same input.

This improves experimental clarity and reduces compute.

End-to-end training may improve performance, but it would make attribution more difficult.

**中文答案**

主要目标是分别研究两个信息层次。

冻结 Stage 1 可以确保所有 Stage 2 模型获得相同输入。

这样提高了实验解释性，也降低了计算成本。

端到端训练可能提高性能，但会让性能提升的来源更难解释。

---

### 69. [Duc] Are the learned embeddings transferable?

**中文问题：学习到的 embedding 是否可迁移？**

**English answer**

The external results suggest some transfer.

However, I did not test linear probing, few-shot learning, or fine-tuning on another dataset.

Therefore, I cannot claim that the embeddings are generally reusable.

Self-supervised pretraining would be a stronger way to study transferability.

**中文答案**

外部结果表明存在一定迁移能力。

但是，我没有测试 linear probing、few-shot learning 或在其他数据集上的微调。

因此，不能声称这些 embedding 普遍可复用。

自监督预训练会是研究可迁移性的更强方法。

---

### 70. [Suzan] Which relation would be useful for DDoS?

**中文问题：哪一种关系对 DDoS 更有用？**

**English answer**

Destination-host context may be useful for DDoS because many sources contact one target.

Source-host context may be more suitable for scanning.

However, my labels are binary, so I cannot test this attack-specific hypothesis.

Attack-family labels are required.

**中文答案**

Destination-host context 可能更适合 DDoS，因为许多源主机会连接同一个目标。

Source-host context 可能更适合扫描。

但当前标签只有二分类，因此无法验证这种攻击特定假设。

需要攻击家族标签。

---

### 71. [Suzan] What is the real network cost of the model?

**中文问题：该模型真实的网络与计算成本是多少？**

**English answer**

I report model parameters, training time, and Stage 2 model-level latency.

I do not measure full energy use, memory, PCAP extraction cost, or end-to-end tail latency.

A deployment study should report throughput, power, memory, and 95th- and 99th-percentile latency.

**中文答案**

论文报告了模型参数量、训练时间和 Stage 2 模型级延迟。

没有测量完整能耗、内存、PCAP 提取成本或端到端尾延迟。

部署研究应报告吞吐量、功耗、内存以及 95 和 99 百分位延迟。

---

### 72. [Janarthanan] What is the practical business value?

**中文问题：该研究的实际业务价值是什么？**

**English answer**

The model may help prioritise suspicious flows that are not clear when viewed alone.

It uses metadata and can work without plaintext payload.

The main practical value is reducing both missed alerts and false alerts.

However, a production pilot is required before making a business claim.

**中文答案**

该模型可能帮助发现单独观察时不明显的可疑 flow。

它使用元数据，不依赖明文 payload。

主要实际价值是同时减少漏报和误报。

但在作出业务价值声明之前，仍然需要生产环境试点。

---

### 73. [Janarthanan] Would you replace Suricata with this model?

**中文问题：你会使用该模型替代 Suricata 吗？**

**English answer**

No.

I would use it as an additional layer.

Suricata rules are fast, interpretable, and useful for known threats.

The model can provide a behavioural score and use cross-flow context.

The two systems can support each other.

**中文答案**

不会。

我会把该模型作为额外的一层。

Suricata 规则速度快、可解释，并且适合已知威胁。

模型可以提供行为分数并使用跨 flow 上下文。

两个系统可以相互补充。

---

### 74. [Janarthanan] How often would the model need updating?

**中文问题：模型需要多久更新一次？**

**English answer**

There is no universal update interval.

It depends on traffic change, alert drift, and operational performance.

I would monitor the model continuously.

Retraining or threshold calibration should be triggered when the score distribution or confirmed error rate changes.

**中文答案**

不存在普遍适用的更新时间。

它取决于流量变化、告警漂移和实际运行表现。

我会持续监控模型。

当分数分布或经过确认的错误率发生变化时，触发重新训练或阈值校准。

---

## Emergency Answer Template — 卡顿时的安全回答

If you do not know the exact answer, use:

**English**

That is a good question.

My current experiment does not measure this directly.

Based on the present design, I expect that …

However, I would need an additional controlled experiment to confirm it.

**中文**

这是一个很好的问题。

我当前的实验没有直接测量这一点。

根据目前的设计，我预计……

但我需要额外的受控实验来确认。

---

If you need time to think, say:

**English**

Thank you. Let me think about that for a moment.

If I understand the question correctly, you are asking whether …

My short answer is …

**中文**

谢谢，请让我思考一下。

如果我正确理解了这个问题，您想问的是……

我的简短回答是……